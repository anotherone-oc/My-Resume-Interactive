function getPosts() {
    console.log("Apel func. getPost");
    fetch('https://jsonplaceholder.typicode.com/posts')
    .then(response => response.json())
    .then(posts => publish(posts));
}
getPosts();

function publish(postsList) {
    for (let i = 0; i <= 99; i++) {
        let post = postsList[i];
        console.log(post);
    }
}
